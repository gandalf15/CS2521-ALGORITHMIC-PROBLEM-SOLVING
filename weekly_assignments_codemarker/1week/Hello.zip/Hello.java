import java.util.*;
public class Hello {
    
    public static void main(String args[]) {
        long start=Long.parseLong(args[0]);
        long end=Long.parseLong(args[1]);
        System.out.println("Hello World "+start+" "+end);
    }
};
